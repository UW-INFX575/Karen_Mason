-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: INFX575
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `test_table`
--

DROP TABLE IF EXISTS `test_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table` (
  `lastname` varchar(100) DEFAULT NULL,
  `facultyyear` smallint(6) DEFAULT NULL,
  `gradyear` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_table`
--

LOCK TABLES `test_table` WRITE;
/*!40000 ALTER TABLE `test_table` DISABLE KEYS */;
INSERT INTO `test_table` VALUES ('Hamilton',0,2012),('Arone',0,0),('Hadley',0,0),('Sekhri',0,0),('Stankovic',0,0),('Holt',0,0),('Qi',0,0),('Wall',0,1992),('Brickhouse',0,1998),('Fraiman',0,1988),('Guroian',0,0),('Ochs',0,0),('Wallace',0,1995),('Abdesselam',0,0),('Coppock',0,0),('Spearing',0,2011),('Cantor',0,1971),('Fowler',0,1992),('Hequembourg',0,2011),('Halvorson-Taylor',0,0),('Imbrie',0,0),('Jones',0,0),('Nair',0,0),('Schaeffer',0,2000),('Schmidt',0,0),('Van Wincoop',0,0),('Hudson',0,0),('Abramenko',0,0),('Maus',0,1982),('Warren',0,0),('Biemann',0,0),('Donovan',0,2013),('Friedberg',0,0),('Hill',0,0),('Johnson',0,0),('Elzinga',0,0),('MacCluer',0,0),('Mark',0,0),('Evans',0,0),('shelat3',0,0),('Felski',0,1987),('Rapinchuk',0,0),('Sherriff',0,0),('Kloosterman',0,0),('Reshef',0,0),('Seitz',0,1990),('Knight',0,0),('Ciliberto',0,0),('Booth',0,1986),('Barnes',0,0),('Lawrence',0,0),('Mahmoody',0,0),('McLaren',0,0),('Skadron',0,0),('Anderson',0,0),('Olsen',0,0),('Levenson',0,1979),('Luftig',0,1988),('Chase',0,1979),('Miller',0,0),('Mills',0,0),('Pasanek',0,2006),('Troyan',0,0),('Ramirez',0,0),('Feldman',0,1976),('Robins',0,0),('Davidson',0,0),('Chalak',0,0),('Chong',0,2004),('Herbst',0,0),('Weimer',0,0),('Whitehouse',0,0),('Chakravorty',0,2005),('Sherman',0,0),('Gromoll',0,0),('Krushkal',0,0),('Melcher',0,0),('Harrigan',0,0),('Engers',0,0),('Bouchard',0,0),('Brien',0,1995),('Jost',0,1985),('Kuhn',0,0),('Michener',0,0),('Olwell',0,2003),('Parshall',0,0),('Ray',0,0),('Ross',0,1983),('Spittler',0,0),('Horton',0,0),('Shuve',0,0),('Weaver',0,0),('Chantell',0,2000),('Errico',0,2000),('Grimshaw',0,0),('Wang',0,0),('Popov',0,0),('Humphrey',0,0),('Floryan',0,0),('Hart',0,0),('Turner',0,0),('Cohoon',0,0),('Kostelnik',0,2013),('Nemec',0,0),('Ogden',0,2010),('Mirman',0,0),('Mukoyama',0,0),('Holt',0,0),('Hedstrom',0,0),('Martin',0,0),('Broyles',0,2014),('Geddes',0,0),('Gilger',0,2014),('Golden',0,2014),('Haley',0,2014),('Hoehler-Fatton',0,0),('Ingle',0,2014),('Kriete',0,0),('Mapp',0,2009),('Marsh',0,1989),('Mohrmann',0,0),('Nowviskie',0,2004),('Papovich',0,1984),('Portmann',0,0),('Rettberg',0,2012),('Rody',0,1995),('Spiegel',0,2013),('Stauffer',0,1998),('Tychonievich',0,0),('Mazur',0,2014),('Lang',0,0),('Sullivan',0,0),('Germano',0,0),('Pepper',0,0),('Krentz',0,2002),('Lasiecka',0,0),('Vander Meulen',0,1981),('Woolfork',0,2000),('Braden',0,1975),('Cushman',0,1982),('Edmundson',0,1985),('Kinney',0,1984),('McGann',0,1966),('Ramazani',0,1988),('Shukla',0,1998),('Tucker',0,1977),('Kinney',0,1983),('Greeson',0,2001),('Alexander',0,0),('al-Rahim',0,0),('Childress',0,0),('Ershov',0,0),('Fogarty',0,0),('Ochs',0,0),('Parshall',0,0),('Stern',0,0),('Thomas',0,0),('Cohen',0,1952),('Railton',0,1975),('Arata',0,1990),('Holsinger',0,1996),('Mathewes',0,1997),(' Smith Richmond',0,2009),('Baker',0,1978),('Abdelbaki',0,0),('Alison',0,0),('Battestin',0,0),('Blair',0,0),('Bourdon',0,0),('Casey',0,0),('Casteen',0,0),('Cole',0,0),('Denton',0,0),('Do',0,0),('Driver',0,0),('Duggan',0,0),('Dunkl',0,0),('Faulkner',0,0),('Goff',0,0),('Grandison',0,0),('Guest',0,0),('Hart',0,0),('Hill',0,0),('Hirsch',0,0),('Howard',0,0),('Howland',0,0),('Huneke',0,0),('Hunter',0,0),('Hurley',0,0),('Kankaanrinta',0,0),('Kelly',0,0),('Kirsch',0,0),('Kolb',0,0),('Korte',0,0),('Langbaum',0,0),('Levenson',0,0),('Livingood',0,0),('Marcantel',0,0),('Martin',0,0),('Mavi',0,0),('McCrimmon',0,0),('Meier',0,0),('Meyer Spacks',0,0),('Morris',0,0),('Nekipelov',0,0),('Nohrnberg',0,0),('Nunez-Betancourt',0,0),('Nystrom',0,0),('Obus',0,0),('Orr',0,0),('Paige',0,0),('Parker',0,0),('Pereira',0,0),('Petrov',0,0),('Pitt',0,0),('Ramsey',0,0),('Rovnyak',0,0),('Russ Spaar',0,0),('Salter',0,0),('Scott',0,0),('Socolovsky',0,0),('Spearing',0,0),('Suarez',0,0),('Sullivan',0,0),('Sullivan',0,0),('Thomasey',0,0),('Tilghman',0,0),('Tosun',0,0),('Townley',0,0),('Wang',0,0),('Ward',0,0),('Webster',0,0),('Wright',0,0),('Zhang',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),('',0,0),(NULL,NULL,NULL);
/*!40000 ALTER TABLE `test_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-21 22:12:51
